# example of using Rpi.GPIO to control Raspberry Pi with Python

import RPi.GPIO as GPIO

GPIO.setmode(GPIO.BCM) # or GPIO.BOARD for direct board numbering

myLED = 3
myButton = 26

GPIO.setup(myLED, GPIO.OUT) # for the LED
GPIO.setup(myButton, GPIO.IN, PULL_UP_DOWN=GPIO.PUD_DOWN) # for the pushbutton

while True:
    if GPIO.input(myButton) :
        GPIO.output(myLED, 1)
    else:
        GPIO.output(myLED, 0)



    
