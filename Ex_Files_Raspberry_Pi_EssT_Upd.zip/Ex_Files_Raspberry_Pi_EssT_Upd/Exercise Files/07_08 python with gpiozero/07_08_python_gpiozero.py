# an example of using gpiozero with python to power a simple switch/led example

from gpiozero import Button, LED

myLED = LED(3)
myButton = Button(26, pull_up=False)

# myLED.blink()

myLED.source = myButton.values

