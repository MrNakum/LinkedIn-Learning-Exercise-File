# example file showing how to use the raspberry pi camera
# picamera documentation at picamera.readthedocs.io

from picamera import PiCamera
import time

myCamera = PiCamera()

for i in range(10):
    myCamera.brightness = i * 10
    myCamera.capture('/home/pi/Desktop/image%s.jpg' % i)
    time.sleep(1)


